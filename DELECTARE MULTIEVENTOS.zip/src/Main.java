import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Gestor gestor_eventos = new Gestor();
        gestor_eventos.menuPrincipal(null);
    }
}
